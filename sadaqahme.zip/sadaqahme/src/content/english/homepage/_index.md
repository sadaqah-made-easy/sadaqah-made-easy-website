---
# Banner
banner:
  title: "Donate to Create Impact"
  content: "You are a fundraiser? Promote through us!"
  image: "/images/homepage/banner-2.jpeg"
  button:
    enable: true
    label: "Request for Promotion"
    link: "#"

  google_play:
    enable: true
    image: /images/homepage/playstore.png
    link: "https://play.google.com/store/apps/details?id=com.sadaqahmadeeasy.app"

  weekly_active_users: "370+"
  last_month_donation: "150+"
  last_month_shares: "705+"
---
